
package noobchain;

import java.util.Date;


public class User {
	public User(String uid ,String name ,double amount) {
		this.amount = amount ;
		this.name =name ;
		this.uid = uid ;
	}
	private String uid;
	private String name;
	private double amount;
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", name=" + name + ", amount=" + amount + "]";
	}


}
