package noobchain;
import com.google.gson.Gson;

import com.google.gson.GsonBuilder;

import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
public class Noobchain
{
  public static ArrayList<Block> blockchain = new ArrayList();
  public static int difficulty = 5;
  public static final long nd = 1000 * 24 * 60 * 60;
  public static final long nh = 1000 * 60 * 60;
  public static final long nm = 1000 * 60;
  public static void main(String[] args) throws InterruptedException
  {
	 
	  //1注册用户
	  
	  System.out.println("模拟用户注册:  张三");
	  User user1 = new User (UUID.randomUUID().toString(),"张三",0.0) ; //卖家
	  Thread.sleep(100);
	  System.out.println("模拟用户注册:  李四");
	  Thread.sleep(100);
	  User user2 = new User (UUID.randomUUID().toString(),"李四",200.0) ; //买家
	  System.out.println("模拟用户注册:  王刚");
	  User user3 = new User (UUID.randomUUID().toString(),"王刚",100.0) ;//买家
	  Thread.sleep(100);
	  //2卖家发布商品
	  	//2.1创建商品
	  Goods goods1 = new  Goods("电子书《福尔摩斯全集》",132.0D,999,user1)  ;
	  System.out.println("模拟用户发布商品:	"+goods1.toString());
	  Thread.sleep(100);
	  Goods goods2 = new  Goods("电子书《哈利波特七步曲》",102.0D,999,user1)  ;
	  System.out.println("模拟用户发布商品 :	"+goods2.toString());
	  Thread.sleep(100);
	  Goods goods3 = new  Goods("电子书《大江大海系列丛书》",110.0D,999,user1)  ;
	  System.out.println("模拟用户发布商品 :	"+goods3.toString());
	  	//2.2创建商品集合
	  List<Goods> gdsList = new  ArrayList<>() ;
	  gdsList.add(goods1);
	  gdsList.add(goods2);
	  gdsList.add(goods3);
	  Thread.sleep(100);
	  //购买商品
	  System.out.println("模拟用户购买商品 ,买方:	李四");
	  Random rand = new Random();
	  int i = rand.nextInt(); //int范围类的随机数
	  i = rand.nextInt(2); //生成0-2以内的随机数
	  i = (int)(Math.random() * 2); //0-2以内的随机数，用Matn.random()方式
	  Goods goods = gdsList.get(i);
	  System.out.println("购买的商品 :	"+goods.toString());
	  Thread.sleep(100);
	  double unitPrice = goods.getUnitPrice();
	  int number = goods.getNumber();
	  goods.setNumber( ++number);
	  Thread.sleep(100);
	  System.out.println("购买的商品数量:1个 商品单价:	"+unitPrice);
	  //生成订单
	  /**
	   * 这里在生成订单的时候，应该加上用户的购买数量，我们默认是购买1 个 ，所以在order 表中没有记录购买数量的字段 number  
	   */
	  Order order = new Order () ;
	  order.setAmount(unitPrice);
	  order.setGoods(goods);
	  order.setOrderStatus(OrderStatus.WAIT_BUYER_PAY);
	  order.setSeller(user1);
      Date now = new Date();
      order.setCreateDate(now.getTime()+"");
      System.out.println("生成订单: "+order.toString());
	  Thread.sleep(100);
	  double amount = user2.getAmount()-unitPrice;
	  user2.setAmount(amount);
	  order.setCreateBy(user2);
	   System.out.println("买方付款 :  "+unitPrice);
	  Thread.sleep(100);
	  String txHash = StringUtil.applySha256(
    	      3 + Long.toString(new Date().getTime()) + Integer.toString(1) + "zxcvbnm");
	  System.out.println("生成交易hash :	"+txHash);
	  Thread.sleep(100);
	  System.out.println("买方账号余额:	"+amount);
	  order.setOrderStatus(OrderStatus.PAY_SUCCESS);
	  Thread.sleep(100);
	  System.out.println("付款成功订单状态为已付款:	"+unitPrice);
	  order.setTxId(txHash);
	  Map<String,Order> orders = new HashMap<>() ;
	  orders.put(txHash, order);
	  //智能合约担保交易
	  IntelligentContract contractObj = new IntelligentContract() ;
	  double contractAmount = contractObj.getAmount();
	  double totalContractAmount =  contractAmount+order.getAmount();
	  contractObj.setAmount(totalContractAmount);
	  contractObj.setOrders(orders);
	  Gson gson = new Gson () ;
	  String contractStr = gson.toJson(contractObj);
	  System.out.println("智能合约担保交易");
	  Thread.sleep(100);
	  System.out.println("通知卖家,买家已付款,交易hash:	"+txHash);
	  Thread.sleep(100);
    blockchain.add(new Block(contractStr, "0"));
    System.out.println("Trying to Mine block1...");
    ((Block)blockchain.get(0)).mineBlock(difficulty);
    
    blockchain.add(new Block(contractStr, ((Block)blockchain.get(blockchain.size() - 1)).hash));
    System.out.println("Trying to Mine block2...");
    ((Block)blockchain.get(1)).mineBlock(difficulty);
    
    blockchain.add(new Block(contractStr, ((Block)blockchain.get(blockchain.size() - 1)).hash));
    System.out.println("Trying to Mine block3...");
    ((Block)blockchain.get(2)).mineBlock(difficulty);
    Thread.sleep(100);
    System.out.println("卖家根据交易hash在区块链中查询 是否存在该订单");
    Block block = blockchain.get(i);
    String data = block.getData();
    IntelligentContract fromJson = gson.fromJson(data, IntelligentContract.class);
    Map<String, Order> ordersMap = fromJson.getOrders();
    Order order2 = ordersMap.get(txHash);
    //TODO 此处判断金额是否正确
    Thread.sleep(100);
    System.out.println("卖家核对订单金额正确");
	  Date now2 = new Date();
	  order2.setDeliveryDate(now2.getTime()+"");
	  ordersMap.put(txHash, order2);
	  System.out.println("卖家发货");
    Thread.sleep(100);
/*    //此处 模拟买家主动收货
    Order order3 = ordersMap.get(txHash);
    receipt(order3,user2);
    */
    
    System.out.println("启动定时任务,监控订单是否超时");
    boolean flag = true;
    //此处 使用 for循环模拟 定时任务
    while(flag) {
        Date now_2 = new Date();
        for (Map.Entry<String , Order> entry : ordersMap.entrySet()) { 
          System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue()); 
          Order orderV = entry.getValue();
          /**
           *在实际的应用中,我们必须判断该订单是否完成,如果完成将不参与 本次for循环.避免重复打款.
           */
          if(!orderV.getOrderStatus().equals(OrderStatus.TRADE_FINISHED)) {
        	  String deliveryDateStr = orderV.getDeliveryDate();
              Date eliveryDate = new Date(Long.parseLong(deliveryDateStr));
              long diff = now_2.getTime()-eliveryDate.getTime() ;
              // 计算差多少分钟
              long min = diff % nd % nh / nm;
              	//TODO 超时时间是2分钟  2L 
              if (min != 2L) {
            	  Thread.sleep(2000);
            	  System.out.println("默认订单距离超时时间为 "+(2L-min)+"分钟");
              } else {
            	  Thread.sleep(150);
            	  System.out.println("订单超时,买家自动确认收货:	"+ entry.getKey());
                  receipt(orderV,user2);
                  //结束程序
                  flag = false ;
              }
          }
          
          
          
        }
    }
    
    
    
  }
  
  private static void  receipt(Order order,User user ) {
	  Double orderV_amount = order.getAmount();
      User seller = order.getSeller();
      double createByAmount = seller.getAmount()+orderV_amount;
      seller.setAmount(createByAmount);
      System.out.println("从智能合约账号 打款给卖家,打款金额:	"+orderV_amount );
      System.out.println("交易完成,更新订单状态 ");
      order.setOrderStatus(OrderStatus.TRADE_FINISHED);
      System.out.println("-----------------------------------------------------------------------");
      System.out.println("卖家账号余额为:	"+seller.getAmount());
      System.out.println("买家账号余额为:	"+user.getAmount());
  }
  
  public static Boolean isChainValid()
  {
    String hashTarget = new String(new char[difficulty]).replace('\000', '0');
    for (int i = 1; i < blockchain.size(); i++)
    {
      Block currentBlock = (Block)blockchain.get(i);
      Block preciousBlock = (Block)blockchain.get(i - 1);
      if (!currentBlock.hash.equals(currentBlock.calculateHash()))
      {
        System.out.println("Current Hashes not equal");
        return Boolean.valueOf(false);
      }
      if (!preciousBlock.hash.equals(currentBlock.previousHash))
      {
        System.out.println("Previous Hashes not equal");
        return Boolean.valueOf(false);
      }
      if (!currentBlock.hash.substring(0, difficulty).equals(hashTarget))
      {
        System.out.println("This block hasn't been mined");
        return Boolean.valueOf(false);
      }
    }
    return Boolean.valueOf(true);
  }
}

