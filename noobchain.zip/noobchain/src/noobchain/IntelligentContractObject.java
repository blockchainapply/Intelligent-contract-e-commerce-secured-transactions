package noobchain;

public class IntelligentContractObject {

}
