package noobchain;

public enum OrderStatus {
	TRADE_FINISHED, //完成
	PAY_SUCCESS,
    WAIT_BUYER_PAY,//待支付
    PAST_DUE,//超时
}
