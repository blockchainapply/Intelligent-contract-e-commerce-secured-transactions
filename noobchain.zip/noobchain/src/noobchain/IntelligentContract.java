package noobchain;

import java.util.List;
import java.util.Map;

public class IntelligentContract {
		private 	  Map<String,Order> orders ;
		private double amount ;
		public Map<String, Order> getOrders() {
			return orders;
		}
		public void setOrders(Map<String, Order> orders) {
			this.orders = orders;
		}
		public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		
		
}
