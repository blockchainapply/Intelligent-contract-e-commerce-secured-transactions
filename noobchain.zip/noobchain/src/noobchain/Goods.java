package noobchain;

public class Goods {
	public Goods(String name,double unitPrice, int number,User  publisher ) {
		this.name=name ;
		this.unitPrice=unitPrice;
		this.number =number ;
		this.publisher =publisher ;
		
	}
	private String name ;
	private double unitPrice ;
	private int number ;
	private User  publisher ;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public User getPublisher() {
		return publisher;
	}
	public void setPublisher(User publisher) {
		this.publisher = publisher;
	}
	@Override
	public String toString() {
		return "Goods [name=" + name + ", unitPrice=" + unitPrice + ", number=" + number + ", publisher=" + publisher
				+ "]";
	}
	

}
