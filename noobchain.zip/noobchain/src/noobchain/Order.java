package noobchain;
import java.util.Date;

public class Order {
	private Goods goods ;
	private String createDate;
	private String deliveryDate ;
	private User createBy;
	private User seller;
	private Double amount ;
	private OrderStatus  orderStatus ;
	private String txId;
	public Goods getGoods() {
		return goods;
	}
	public void setGoods(Goods goods) {
		this.goods = goods;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public User getCreateBy() {
		return createBy;
	}
	public void setCreateBy(User createBy) {
		this.createBy = createBy;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public OrderStatus getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getTxId() {
		return txId;
	}
	public void setTxId(String txId) {
		this.txId = txId;
	}
	@Override
	public String toString() {
		return "Order [goods=" + goods + ", createDate=" + createDate + ", deliveryDate=" + deliveryDate + ", createBy="
				+ createBy + ", amount=" + amount + ", orderStatus=" + orderStatus + ", txId=" + txId + "]";
	}
	public User getSeller() {
		return seller;
	}
	public void setSeller(User seller) {
		this.seller = seller;
	}
	

}
